//
//  CodePushViewController.swift
//  ScreenTransition
//
//  Created by mac on 2022/09/27.
//

import UIKit

class CodePushViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

  
    }
    
    @IBAction func tapBackButton(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    

}
